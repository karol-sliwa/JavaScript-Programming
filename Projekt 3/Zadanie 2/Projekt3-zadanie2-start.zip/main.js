let size = 10;
let orderElement = 1;

const init = () => {
 // tutaj kod
}

const createLiElements = () => {
 // tutaj kod
}

init()